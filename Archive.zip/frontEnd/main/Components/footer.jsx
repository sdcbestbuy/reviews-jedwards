import React from 'react';


const Footer = (props) =>{
  return (
    <div id='FooterMain'>
      <button id='ShowMoreBTN'>Show More</button>
      <button id='WriteAReviewBTN'>Write a Review</button>
    </div>
  )
}

export default Footer;